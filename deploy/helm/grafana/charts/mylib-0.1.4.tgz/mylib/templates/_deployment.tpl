{{- define "mylib.deployment" -}}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Release.Name }}
  labels:
    app: {{ .Release.Name }}
    {{- with .Values.labels }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
spec:
  replicas: {{ .Values.replicaCount | default 1 }}
  selector:
    matchLabels:
      app: {{ .Release.Name }}
  template:
    metadata:
      labels:
        app: {{ .Release.Name }}
        {{- with .Values.podLabels }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
    spec:
      # --- БЕЗОПАСНОСТЬ ПОДА (Гибкие настройки пользователя) ---
      securityContext:
        runAsNonRoot: true
        runAsUser: {{ .Values.securityContext.runAsUser | default 1000 }}
        fsGroup: {{ .Values.securityContext.fsGroup | default 2000 }}

      {{- with .Values.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}

      containers:
        - name: {{ .Chart.Name }}
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag | default "latest" }}"
          imagePullPolicy: {{ .Values.image.pullPolicy | default "IfNotPresent" }}

          # --- УНИВЕРСАЛЬНАЯ КОМАНДА (Для Busybox/Воркеров) ---
          {{- if .Values.command }}
          command: {{ toYaml .Values.command | nindent 12 }}
          {{- end }}

          # --- АРГУМЕНТЫ КОМАНДЫ ---
          {{- if .Values.args }}
          args: {{ toYaml .Values.args | nindent 12 }}
          {{- end }}

          # --- ЖЕСТКАЯ ЗАЩИТА КОНТЕЙНЕРА ---
          securityContext:
            allowPrivilegeEscalation: false
            readOnlyRootFilesystem: {{ if .Values.securityContext }}{{ .Values.securityContext.readOnlyRootFilesystem | default true }}{{ else }}true{{ end }}
            capabilities:
              drop:
                - ALL

          # --- ДИНАМИЧЕСКИЕ ПЕРЕМЕННЫЕ ОКРУЖЕНИЯ ---
          {{- if .Values.env }}
          env:
            {{- toYaml .Values.env | nindent 12 }}
          {{- end }}

          # --- envFrom (подключение Secret/ConfigMap целиком) ---
          {{- with .Values.envFrom }}
          envFrom:
            {{- toYaml . | nindent 12 }}
          {{- end }}

          # --- ДИНАМИЧЕСКИЕ МОНТИРОВАНИЯ (volumeMounts) ---
          volumeMounts:
            - name: tmp-volume
              mountPath: /tmp
            {{- if .Values.persistence }}
            {{- if .Values.persistence.mounts }}
            {{- toYaml .Values.persistence.mounts | nindent 12 }}
            {{- end }}
            {{- end }}
            {{- with .Values.volumeMounts }}
            {{- toYaml . | nindent 12 }}
            {{- end }}

          # --- ПРОБНИКИ (livenessProbe / readinessProbe) ---
          {{- with .Values.livenessProbe }}
          livenessProbe:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          
          {{- with .Values.readinessProbe }}
          readinessProbe:
            {{- toYaml . | nindent 12 }}
          {{- end }}

          ports:
            - containerPort: {{ .Values.service.targetPort | default 8080 }}
              name: http
              protocol: TCP

          # --- ЛИМИТЫ РЕСУРСОВ ---
          resources:
            {{- if .Values.resources }}
            {{- toYaml .Values.resources | nindent 12 }}
            {{- else }}
            requests:
              cpu: 100m
              memory: 128Mi
            limits:
              cpu: 500m
              memory: 256Mi
            {{- end }}

      # --- ОПИСАНИЕ ДИСКОВ (volumes) ---
      volumes:
        - name: tmp-volume
          emptyDir: {}
        {{- if .Values.persistence }}
        {{- if .Values.persistence.volumes }}
        {{- toYaml .Values.persistence.volumes | nindent 8 }}
        {{- end }}
        {{- end }}
        {{- with .Values.volumes }}
        {{- toYaml . | nindent 8 }}
        {{- end }}

      # --- УЗЛЫ И ЗОНЫ ---
      {{- with .Values.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      
      {{- with .Values.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      
      {{- with .Values.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}

      # --- СЕРВИСНАЯ УЧЁТКА ---
      {{- with .Values.serviceAccountName }}
      serviceAccountName: {{ . }}
      {{- end }}

      # --- ИНИЦИАЛИЗАЦИОННЫЕ КОНТЕЙНЕРЫ ---
      {{- with .Values.initContainers }}
      initContainers:
        {{- toYaml . | nindent 8 }}
      {{- end }}

      # --- ХОСТ СЕТЬ (для особых случаев) ---
      {{- if .Values.hostNetwork }}
      hostNetwork: true
      {{- end }}
      
      {{- with .Values.dnsPolicy }}
      dnsPolicy: {{ . }}
      {{- end }}
{{- end -}}

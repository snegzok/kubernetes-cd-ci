{{- define "mylib.deployment" -}}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Release.Name }}
  labels:
    app: {{ .Release.Name }}
spec:
  replicas: {{ .Values.replicaCount | default 1 }}
  selector:
    matchLabels:
      app: {{ .Release.Name }}
  template:
    metadata:
      labels:
        app: {{ .Release.Name }}
    spec:
      # --- БЕЗОПАСНОСТЬ ПОДА ---
      securityContext:
        runAsNonRoot: true
        runAsUser: 101 # Для Nginx лучше 101, для Python 1000. В проде часто выносят в values.
        fsGroup: 2000
      containers:
        - name: {{ .Chart.Name }}
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag | default "latest" }}"
          
          # --- ЖЕСТКАЯ ЗАЩИТА КОНТЕЙНЕРА ---
          securityContext:
            allowPrivilegeEscalation: false
            # Позволяем переопределять из values (для тестов), по умолчанию true
            readOnlyRootFilesystem: {{ if .Values.securityContext }}{{ .Values.securityContext.readOnlyRootFilesystem | default true }}{{ else }}true{{ end }}
            capabilities:
              drop:
                - ALL

          # --- ДИНАМИЧЕСКИЕ ПЕРЕМЕННЫЕ ОКРУЖЕНИЯ ---
          {{- if .Values.env }}
          env:
            {{- toYaml .Values.env | nindent 12 }}
          {{- end }}

          # --- ДИНАМИЧЕСКИЕ МОНТИРОВАНИЯ (volumeMounts) ---
          volumeMounts:
            - name: tmp-volume
              mountPath: /tmp
            {{- if .Values.persistence.mounts }}
            {{- toYaml .Values.persistence.mounts | nindent 12 }}
            {{- end }}

          ports:
            - containerPort: {{ .Values.service.targetPort | default 8080 }}

          # --- ЛИМИТЫ РЕСУРСОВ (Берем из values приложения) ---
          resources:
            {{- toYaml .Values.resources | nindent 12 }}

      # --- ОПИСАНИЕ ДИСКОВ (volumes) ---
      volumes:
        - name: tmp-volume
          emptyDir: {}
        {{- if .Values.persistence.volumes }}
        {{- toYaml .Values.persistence.volumes | nindent 8 }}
        {{- end }}
{{- end -}}

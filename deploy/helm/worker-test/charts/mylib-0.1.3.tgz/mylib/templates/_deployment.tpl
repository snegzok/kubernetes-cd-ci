{{- define "mylib.deployment" -}}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Release.Name }}
  labels:
    app: {{ .Release.Name }}
spec:
  replicas: {{ .Values.replicaCount | default 1 }}
  selector:
    matchLabels:
      app: {{ .Release.Name }}
  template:
    metadata:
      labels:
        app: {{ .Release.Name }}
    spec:
      # --- БЕЗОПАСНОСТЬ ПОДА (Гибкие настройки пользователя) ---
      securityContext:
        runAsNonRoot: true
        runAsUser: {{ .Values.securityContext.runAsUser | default 1000 }}
        fsGroup: {{ .Values.securityContext.fsGroup | default 2000 }}
      
      containers:
        - name: {{ .Chart.Name }}
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag | default "latest" }}"

          # --- УНИВЕРСАЛЬНАЯ КОМАНДА (Для Busybox/Воркеров) ---
          {{- if .Values.command }}
          command: {{ toYaml .Values.command | nindent 12 }}
          {{- end }}

          # --- ЖЕСТКАЯ ЗАЩИТА КОНТЕЙНЕРА ---
          securityContext:
            allowPrivilegeEscalation: false
            readOnlyRootFilesystem: {{ if .Values.securityContext }}{{ .Values.securityContext.readOnlyRootFilesystem | default true }}{{ else }}true{{ end }}
            capabilities:
              drop:
                - ALL

          # --- ДИНАМИЧЕСКИЕ ПЕРЕМЕННЫЕ ОКРУЖЕНИЯ ---
          {{- if .Values.env }}
          env:
            {{- toYaml .Values.env | nindent 12 }}
          {{- end }}

          # --- ДИНАМИЧЕСКИЕ МОНТИРОВАНИЯ (volumeMounts) ---
          volumeMounts:
            - name: tmp-volume
              mountPath: /tmp
            {{- if .Values.persistence }}
            {{- if .Values.persistence.mounts }}
            {{- toYaml .Values.persistence.mounts | nindent 12 }}
            {{- end }}
            {{- end }}

          ports:
            - containerPort: {{ .Values.service.targetPort | default 8080 }}

          # --- ЛИМИТЫ РЕСУРСОВ ---
          resources:
            {{- if .Values.resources }}
            {{- toYaml .Values.resources | nindent 12 }}
            {{- else }}
            requests:
              cpu: 100m
              memory: 128Mi
            limits:
              cpu: 500m
              memory: 256Mi
            {{- end }}

      # --- ОПИСАНИЕ ДИСКОВ (volumes) ---
      volumes:
        - name: tmp-volume
          emptyDir: {}
        {{- if .Values.persistence }}
        {{- if .Values.persistence.volumes }}
        {{- toYaml .Values.persistence.volumes | nindent 8 }}
        {{- end }}
        {{- end }}
{{- end -}}
